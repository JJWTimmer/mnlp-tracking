import os
from setuptools import setup
from setuptools.extension import Extension

cHeatmap = Extension(
    name='cHeatmap',
    sources=['heatmap/heatmap.c', ]
)

setup(name='heatmap',
      version="2.2",
      description='Module to create heatmaps',
      author='Jeffrey J. Guy',
      author_email='jjg@case.edu',
      url='http://jjguy.com/heatmap/',
      license='MIT License',
      
      #real stuff
      packages=['heatmap', ],
      ext_modules=[cHeatmap, ],
      install_requires=["Pillow", ],
      test_suite="test",
      tests_require=["Pillow", ],
      )